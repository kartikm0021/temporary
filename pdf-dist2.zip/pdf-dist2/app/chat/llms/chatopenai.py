from langchain.chat_models import ChatOpenAI


def build_llm(chat_args):
    return ChatOpenAI()
